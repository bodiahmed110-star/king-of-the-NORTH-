King of Challenge - Vercel API

الملفات:
api/register.js
api/admin-state.js

متغيرات Vercel المطلوبة:
SUPABASE_URL
SUPABASE_PUBLISHABLE_KEY
SUPABASE_SECRET_KEY

مهم:
لا تضع SUPABASE_SECRET_KEY داخل GitHub أو داخل ملفات الواجهة الأمامية.
أضفه فقط في Vercel > Project Settings > Environment Variables.
