const SUPABASE_URL = process.env.SUPABASE_URL || 'https://rfgctdcrcyxmuzaqntut.supabase.co';
const SUPABASE_SECRET_KEY = process.env.SUPABASE_SECRET_KEY || process.env.SUPABASE_SUPABASE_SECRET_KEY;

function usernameHex(value) {
  const bytes = new TextEncoder().encode(String(value || '').trim().toLowerCase());
  let hex = '';
  for (const b of bytes) hex += b.toString(16).padStart(2, '0');
  return hex;
}

function authEmail(username) {
  return `u_${usernameHex(username)}@koc.local`;
}

function validUsername(value) {
  const username = String(value || '').trim();
  return (
    username.length >= 2 &&
    username.length <= 60 &&
    /[\p{L}\p{N}]/u.test(username) &&
    !/[\u0000-\u001F\u007F]/.test(username)
  );
}

function send(res, status, body) {
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  res.end(JSON.stringify(body));
}

module.exports = async function handler(req, res) {
  if (req.method === 'OPTIONS') {
    res.statusCode = 204;
    return res.end();
  }

  if (req.method !== 'POST') {
    return send(res, 405, { message: 'Method not allowed' });
  }

  if (!SUPABASE_SECRET_KEY) {
    return send(res, 500, {
      message: 'Server configuration missing: SUPABASE_SECRET_KEY'
    });
  }

  try {
    let body = req.body;
    if (typeof body === 'string') body = JSON.parse(body);
    body = body || {};

    const name = String(body.name || '').trim();
    const username = String(body.username || '').trim().toLowerCase();
    const contactEmail = String(body.contactEmail || '').trim().toLowerCase();
    const password = String(body.password || '');

    if (!name || !validUsername(username) || password.length < 6) {
      return send(res, 400, { message: 'البيانات غير صحيحة.' });
    }

    const headers = {
      apikey: SUPABASE_SECRET_KEY,
      Authorization: `Bearer ${SUPABASE_SECRET_KEY}`,
      'Content-Type': 'application/json'
    };

    const create = await fetch(`${SUPABASE_URL}/auth/v1/admin/users`, {
      method: 'POST',
      headers,
      body: JSON.stringify({
        email: authEmail(username),
        password,
        email_confirm: true,
        user_metadata: {
          game_username: username,
          display_name: name,
          contact_email: contactEmail
        }
      })
    });

    const createText = await create.text();
    let created = {};
    try {
      created = JSON.parse(createText);
    } catch (_) {
      created = { message: createText };
    }

    if (!create.ok) {
      const raw = String(created.msg || created.message || createText || '');
      if (/already|exists|registered|duplicate/i.test(raw)) {
        return send(res, 409, { message: 'اسم حساب اللعبة مستخدم بالفعل.' });
      }
      return send(res, 400, { message: `تعذر إنشاء الحساب. ${raw}` });
    }

    const userId = created.id;

    const profile = await fetch(`${SUPABASE_URL}/rest/v1/profiles?on_conflict=id`, {
      method: 'POST',
      headers: {
        ...headers,
        Prefer: 'resolution=merge-duplicates,return=minimal'
      },
      body: JSON.stringify({
        id: userId,
        game_username: username,
        display_name: name,
        status: 'pending',
        is_admin: false,
        contact_email: contactEmail || ''
      })
    });

    if (!profile.ok) {
      try {
        await fetch(`${SUPABASE_URL}/auth/v1/admin/users/${encodeURIComponent(userId)}`, {
          method: 'DELETE',
          headers
        });
      } catch (_) {}

      const txt = await profile.text();
      return send(res, 500, {
        message: `تم إنشاء الحساب ثم تعذر حفظ ملف المدرب. ${txt}`
      });
    }

    return send(res, 201, { ok: true, userId });
  } catch (error) {
    console.error(error);
    return send(res, 500, {
      message: 'حدث خطأ غير متوقع في خادم التسجيل.'
    });
  }
};
