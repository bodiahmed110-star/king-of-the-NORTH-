const SUPABASE_URL = process.env.SUPABASE_URL || 'https://rfgctdcrcyxmuzaqntut.supabase.co';
const PUBLISHABLE_KEY = process.env.SUPABASE_PUBLISHABLE_KEY || 'sb_publishable_IWVPqIF5pggz_arFItHVFA_9ThgTnUQ';
const SUPABASE_SECRET_KEY = process.env.SUPABASE_SECRET_KEY || process.env.SUPABASE_SUPABASE_SECRET_KEY;

function send(res, status, body) {
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  res.end(JSON.stringify(body));
}

module.exports = async function handler(req, res) {
  if (req.method === 'OPTIONS') {
    res.statusCode = 204;
    return res.end();
  }

  if (req.method !== 'POST') {
    return send(res, 405, { message: 'Method not allowed' });
  }

  if (!SUPABASE_SECRET_KEY) {
    return send(res, 500, {
      message: 'Server configuration missing: SUPABASE_SECRET_KEY'
    });
  }

  try {
    const auth = String(req.headers.authorization || '');
    if (!auth.startsWith('Bearer ')) {
      return send(res, 401, { message: 'غير مصرح.' });
    }

    const accessToken = auth.slice(7);

    const userResp = await fetch(`${SUPABASE_URL}/auth/v1/user`, {
      headers: {
        apikey: PUBLISHABLE_KEY,
        Authorization: `Bearer ${accessToken}`
      }
    });

    if (!userResp.ok) {
      return send(res, 401, {
        message: 'انتهت جلسة الإدارة. سجّل الدخول مرة أخرى.'
      });
    }

    const user = await userResp.json();

    const adminResp = await fetch(
      `${SUPABASE_URL}/rest/v1/admin_users?user_id=eq.${encodeURIComponent(user.id)}&select=user_id&limit=1`,
      {
        headers: {
          apikey: SUPABASE_SECRET_KEY,
          Authorization: `Bearer ${SUPABASE_SECRET_KEY}`
        }
      }
    );

    if (!adminResp.ok) {
      return send(res, 500, { message: 'تعذر التحقق من صلاحية الإدارة.' });
    }

    const admins = await adminResp.json();
    if (!Array.isArray(admins) || admins.length === 0) {
      return send(res, 403, { message: 'هذا الحساب ليس حساب إدارة.' });
    }

    let body = req.body;
    if (typeof body === 'string') body = JSON.parse(body);
    body = body || {};

    const data = body.data;
    if (!data || typeof data !== 'object' || Array.isArray(data)) {
      return send(res, 400, { message: 'بيانات المزامنة غير صحيحة.' });
    }

    const upsert = await fetch(`${SUPABASE_URL}/rest/v1/site_state?on_conflict=id`, {
      method: 'POST',
      headers: {
        apikey: SUPABASE_SECRET_KEY,
        Authorization: `Bearer ${SUPABASE_SECRET_KEY}`,
        'Content-Type': 'application/json',
        Prefer: 'resolution=merge-duplicates,return=minimal'
      },
      body: JSON.stringify({
        id: 1,
        data,
        updated_at: new Date().toISOString()
      })
    });

    if (!upsert.ok) {
      const txt = await upsert.text();
      return send(res, 500, {
        message: `تعذر حفظ بيانات الموقع في Supabase. ${txt}`
      });
    }

    return send(res, 200, { ok: true });
  } catch (error) {
    console.error(error);
    return send(res, 500, {
      message: 'حدث خطأ غير متوقع أثناء مزامنة الموقع.'
    });
  }
};
